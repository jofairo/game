const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");

const app = express();
app.use(cors());
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
  },
});

let players = {};
let currentQuestion = null;
let correctAnswer = "";

const questions = [
  {
    prompt: "Wat is de hoofdstad van Frankrijk?",
    options: ["Parijs", "Rome", "Madrid"],
    answer: "Parijs",
  },
  {
    prompt: "Welke vlag hoort bij Duitsland?",
    options: ["🇩🇪", "🇫🇷", "🇪🇸"],
    answer: "🇩🇪",
  },
  {
    prompt: "Tot welk continent behoort Argentinië?",
    options: ["Zuid-Amerika", "Europa", "Azië"],
    answer: "Zuid-Amerika",
  },
];

function sendNewQuestion() {
  const q = questions[Math.floor(Math.random() * questions.length)];
  currentQuestion = q;
  correctAnswer = q.answer;
  io.emit("question", {
    prompt: q.prompt,
    options: q.options.sort(() => 0.5 - Math.random()),
  });
}

io.on("connection", (socket) => {
  console.log("Gebruiker verbonden:", socket.id);

  socket.on("join", (name) => {
    players[socket.id] = { name, score: 0 };
    io.emit("players", Object.values(players).map((p) => p.name));
    io.emit("scoreboard", Object.values(players));
    if (Object.keys(players).length >= 2 && !currentQuestion) {
      sendNewQuestion();
    }
  });

  socket.on("answer", ({ name, answer }) => {
    const player = players[socket.id];
    if (!player || !currentQuestion) return;

    if (answer === correctAnswer) {
      player.score += 1;
    }

    io.emit("scoreboard", Object.values(players));

    setTimeout(() => {
      sendNewQuestion();
    }, 3000);
  });

  socket.on("disconnect", () => {
    delete players[socket.id];
    io.emit("players", Object.values(players).map((p) => p.name));
    io.emit("scoreboard", Object.values(players));
  });
});

server.listen(process.env.PORT || 3000, () => {
  console.log("Server draait op poort 3000");
});